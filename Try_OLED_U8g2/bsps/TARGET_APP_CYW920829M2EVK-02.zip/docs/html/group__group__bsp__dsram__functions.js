var group__group__bsp__dsram__functions =
[
    [ "cybsp_syspm_do_warmboot", "group__group__bsp__dsram__functions.html#gaeaa97ebf2a7a769589bf24bb2d306fb4", null ],
    [ "cybsp_syspm_dsram_init", "group__group__bsp__dsram__functions.html#gae9217e4b92ef5f9cda69a3bc26b9a5a8", null ],
    [ "syspmBspDeepSleepEntryPoint", "group__group__bsp__dsram__functions.html#ga2f87313c9926c64f8f8cac002a3b0e2f", null ]
];