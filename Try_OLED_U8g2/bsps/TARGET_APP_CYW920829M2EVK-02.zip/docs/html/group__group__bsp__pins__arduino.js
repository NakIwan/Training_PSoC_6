var group__group__bsp__pins__arduino =
[
    [ "CYBSP_A0", "group__group__bsp__pins__arduino.html#gae4c804044ed1e8745433efc32f1e3de5", null ],
    [ "CYBSP_A1", "group__group__bsp__pins__arduino.html#gaeb5533ea084a75773bd3f2aaf3363ac9", null ],
    [ "CYBSP_A2", "group__group__bsp__pins__arduino.html#ga3e497e03e8e9d8bd597f01426bc4b70a", null ],
    [ "CYBSP_A3", "group__group__bsp__pins__arduino.html#ga53d1f02f664bd82f42989ffa5d34912e", null ],
    [ "CYBSP_D0", "group__group__bsp__pins__arduino.html#gaf3f59a1b7b94013adedd43cf3598af0a", null ],
    [ "CYBSP_D1", "group__group__bsp__pins__arduino.html#ga815d622465be76739d8e71d75725b7a5", null ],
    [ "CYBSP_D2", "group__group__bsp__pins__arduino.html#ga87244e296d0eefe46f1bb9a579b435fa", null ],
    [ "CYBSP_D3", "group__group__bsp__pins__arduino.html#ga77222cbe7f9f94826b9970c6bc4843aa", null ],
    [ "CYBSP_D4", "group__group__bsp__pins__arduino.html#ga909572ea000d856223c6298cfd4fd067", null ],
    [ "CYBSP_D5", "group__group__bsp__pins__arduino.html#gae918eeaea45fa81576613eebef34335b", null ],
    [ "CYBSP_D6", "group__group__bsp__pins__arduino.html#gaa436fdcdd1417ce4db7d0d8d4615d60b", null ],
    [ "CYBSP_D7", "group__group__bsp__pins__arduino.html#ga0875edb9e551c5eb01ac66dd27faf33a", null ],
    [ "CYBSP_D8", "group__group__bsp__pins__arduino.html#ga403c81e9f770b42e8a77668c9695b2dd", null ],
    [ "CYBSP_D9", "group__group__bsp__pins__arduino.html#gab89ecd0381439ac9c927af7538f2afc4", null ],
    [ "CYBSP_D10", "group__group__bsp__pins__arduino.html#ga1246432b2f280267d3b9fd90028f6244", null ],
    [ "CYBSP_D11", "group__group__bsp__pins__arduino.html#gac7cddcd52b382156d8cb1af96d7988b8", null ],
    [ "CYBSP_D12", "group__group__bsp__pins__arduino.html#gaf9602a0824b644e2c54716c328b659e8", null ],
    [ "CYBSP_D13", "group__group__bsp__pins__arduino.html#gabe652026d9d18fa2c626f744e260e36e", null ]
];